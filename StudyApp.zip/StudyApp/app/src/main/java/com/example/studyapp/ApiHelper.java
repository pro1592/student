package com.example.studyapp;

import com.android.volley.RequestQueue;

public class ApiHelper {
    public static RequestQueue requestQueue;
    public static String host = "https://openapi.naver.com/v1/papago/n2mt";
    public static String clientId = "gtl5Q02VzgOKtoPguEO0";
    public static String clientSecret = "3TLNjCUdIR";
}
