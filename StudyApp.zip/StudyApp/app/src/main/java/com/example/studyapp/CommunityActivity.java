package com.example.studyapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class CommunityActivity extends AppCompatActivity {

    private FirebaseFirestore firebaseFirestore;

    private String current_user_id;

    private FirebaseAuth mAuth;
    private FloatingActionButton addPostBtn;

    private CommunityFragment communityFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community);

        ActionBar bar = getSupportActionBar();
        bar.hide();

        mAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();

        if (mAuth.getCurrentUser() != null) {
            communityFragment = new CommunityFragment();

            replaceFragment(communityFragment);

            addPostBtn = findViewById(R.id.add_post_btn);

            addPostBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(CommunityActivity.this, NewPostActivity.class);
                    startActivity(intent);

                }
            });
        }
    }

    private void replaceFragment(Fragment fragment){

        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.main_post_container, fragment);
        fragmentTransaction.commit();

    }

    @Override
    protected void onStart() {
        super.onStart();

        current_user_id = mAuth.getCurrentUser().getUid();

        firebaseFirestore.collection("Users").document(current_user_id).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {

                if (task.isSuccessful()) {
                    if (!task.getResult().exists()){

                        Intent setupIntent = new Intent(CommunityActivity.this,setupActivity.class);
                        startActivity(setupIntent);
                        finish();

                    }
                } else {
                    String error = task.getException().getMessage();
                    Toast.makeText(CommunityActivity.this, "에러 : " + error, Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}