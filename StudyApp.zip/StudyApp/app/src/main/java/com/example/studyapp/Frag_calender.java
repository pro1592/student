package com.example.studyapp;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.applandeo.materialcalendarview.CalendarView;
import com.applandeo.materialcalendarview.EventDay;
import com.applandeo.materialcalendarview.listeners.OnDayClickListener;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Frag_calender extends Fragment {

    private View view;

    //firebase auth object
    private FirebaseAuth firebaseAuth;

    //firebase data object
    private DatabaseReference mDatabaseReference; // 데이터베이스의 주소를 저장합니다.
    private FirebaseDatabase mFirebaseDatabase; // 데이터베이스에 접근할 수 있는 진입점 클래스입니다.
    private FirebaseUser user;

    Button btnAdd;

    private RecyclerView recyclerView;// 선택한 날짜의 일정을 쓰거나 기존에 저자된 일기가 있다면 보여주고 수정하는 영역
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<TodoList> arrayList;

    // 선택한 날짜
    int checkYear;
    int checkMonth;
    int checkDay;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.frag_calender, container, false);

        // initializing database
        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();

        mFirebaseDatabase = FirebaseDatabase.getInstance();

        //뷰에 있는 위젯들 리턴받기기
        recyclerView = view.findViewById(R.id.rv_calenderTodo);
        btnAdd = view.findViewById(R.id.btnAdd);
        CalendarView calendarView = view.findViewById(R.id.calendarView01);
        List<EventDay> events = new ArrayList<>();
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        arrayList = new ArrayList<>();

        // 오늘 날짜 받게하기
        Calendar today= Calendar.getInstance();
        int todayYear=today.get(Calendar.YEAR);
        int todayMonth=today.get(Calendar.MONTH);
        int todayDay=today.get(Calendar.DAY_OF_MONTH);

        // 현재 선택한 날짜
        checkYear = todayYear;
        checkMonth = todayMonth;
        checkDay = todayDay;

        // 첫시작 할 때 오늘 날짜 일정 읽어주기
        checkedDay(todayYear, todayMonth, todayDay);

        mDatabaseReference = mFirebaseDatabase.getReference().child("calendar").child(user.getUid()).child(checkYear + "-" + checkMonth + "-" + checkDay);
        mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //파이어베이스 내의 데이터 받아오는 메서드
                arrayList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {   //반복문으로 데이터 list 추출
                    TodoList todoList = dataSnapshot.getValue(TodoList.class);
                    arrayList.add(todoList);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        adapter = new TodoAdapter(arrayList, getActivity());
        recyclerView.setAdapter(adapter);

        // 선택 날짜가 변경될 때 호출되는 리스너
        calendarView.setOnDayClickListener(new OnDayClickListener() {
            @Override
            public void onDayClick(EventDay eventDay) {
                Calendar clickedDayCalendar = eventDay.getCalendar();
                //이미 선택한 날짜에 일기가 있는지 없는지 체크
                checkedDay(clickedDayCalendar.get(Calendar.YEAR),
                        clickedDayCalendar.get(Calendar.MONTH),
                        clickedDayCalendar.get(Calendar.DATE));
                //체크한 날짜 변경
                checkYear = clickedDayCalendar.get(Calendar.YEAR);
                checkMonth = clickedDayCalendar.get(Calendar.MONTH);
                checkDay = clickedDayCalendar.get(Calendar.DATE);
            }
        });

        //추가 버튼 누르면 실행되는 리스너
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //fileName을 넣고 저장시키는 메소드를 호출
                addTask();
            }
        });

        return  view;
    }

    //일정 Database 읽기
    private void checkedDay(int year, int monthOfYear, int dayOfMonth) {
        // mDatabaseReference의 경로를 filebase/diary/userUid/date 로 설정
        mDatabaseReference = mFirebaseDatabase.getReference().child("calendar").child(user.getUid()).child(year + "-" + monthOfYear + "-" + dayOfMonth);
        mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                arrayList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {   //반복문으로 데이터 list 추출
                    TodoList todoList = snapshot.getValue(TodoList.class);
                    arrayList.add(todoList);
                }
                adapter.notifyDataSetChanged();

            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {  }
        });

        adapter = new TodoAdapter(arrayList, getActivity());
        recyclerView.setAdapter(adapter);
    }

    //문자열을 int로 변환한다.
    private int[] splitDate(String date){
        String[] splitText = date.split("-");
        int[] result_date = {Integer.parseInt(splitText[0]), Integer.parseInt(splitText[1]), Integer.parseInt(splitText[2])};
        return result_date;
    }

    private void addTask(){
        AlertDialog.Builder myDialog = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = LayoutInflater.from(getActivity());

        View myView = inflater.inflate(R.layout.todo_input_file, null);
        myDialog.setView(myView);

        final AlertDialog dialog = myDialog.create();
        dialog.setCancelable(false);

        final EditText task = myView.findViewById(R.id.edtTask);
        Button save = myView.findViewById(R.id.btnSave);
        Button cancel = myView.findViewById(R.id.btnCancel);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        //일정 저장하는 메소드
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDatabaseReference = mFirebaseDatabase.getReference().child("calendar").child(user.getUid()).child(checkYear + "-" + checkMonth + "-" + checkDay);
                String mTask = task.getText().toString().trim();
                String id = mDatabaseReference.push().getKey();

                if(TextUtils.isEmpty(mTask)){
                    task.setError("일정을 추가하세요");
                    return;
                }else {
                    Todo_Model todo_model = new Todo_Model(mTask,id);
                    mDatabaseReference.child(id).setValue(todo_model).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                //일정이 저장되면 토스메세지로 "일정 저장 됨"
                                Toast.makeText(getActivity(),"일정 저장 완료",Toast.LENGTH_SHORT).show();
                            }else {
                                String error = task.getException().toString();
                                Toast.makeText(getActivity(),"저장 실패 : " + error,Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }

                dialog.dismiss();
            }
        });

        dialog.show();
    }



}
