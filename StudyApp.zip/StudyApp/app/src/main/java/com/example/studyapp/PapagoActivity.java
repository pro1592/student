package com.example.studyapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import static android.speech.tts.TextToSpeech.ERROR;

public class PapagoActivity extends AppCompatActivity {

    final int PERMISSION = 1;
    private int REQUEST_CODE_SPEECH_INPUT = 100;
    int OPTION=1;

    EditText inputText;
    TextView outText;
    EditText inputText2;

    Button setInLng_btn;
    Button setOutLng_btn;

    LinearLayout setInLngList;
    LinearLayout setOutLngList;

    Button btnTranslate;
    Button btnSpeak;
    Button btnSpeak0;
    Button btnStop;
    Button btnImageText;
    ImageButton btnVoice;
    Button speachtest_btn;

    Button inKo_btn;
    Button outKo_btn;
    Button inEn_btn;
    Button outEn_btn;

    Animation inputTranslateUp;
    Animation inputTranslateDown;
    Animation outputTranslateUp;
    Animation outputTranslateDown;

    boolean inputIsShown = false;
    boolean outputIsShown = false;

    String inputLng;
    String outputLng;

    private TextToSpeech tts0;
    private TextToSpeech tts;


    Intent mIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_papago);

        if (ApiHelper.requestQueue == null) {
            ApiHelper.requestQueue = Volley.newRequestQueue(getApplicationContext());
        }

        // 안드로이드 6.0버전 이상인지 체크해서 퍼미션 체크
        if (Build.VERSION.SDK_INT >= 23) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET,
                    Manifest.permission.RECORD_AUDIO}, PERMISSION);
        }

        inputText = findViewById(R.id.inputText1);
        inputText2 = findViewById(R.id.inputText2);
        outText = findViewById(R.id.outText1);
        setInLng_btn = findViewById(R.id.setInLng_btn);
        setOutLng_btn = findViewById(R.id.setOutLng_btn);
        setInLngList = findViewById(R.id.setInLngList);
        setOutLngList = findViewById(R.id.setOutLngList);
        btnTranslate = findViewById(R.id.btnTranslate1);
        btnSpeak0 = findViewById(R.id.speakBtn1);
        btnSpeak = findViewById(R.id.speakBtn2);
        btnStop = findViewById(R.id.stopBtn1);
        btnImageText = findViewById(R.id.next1);
        btnVoice = findViewById(R.id.voiceBtn1);
        inKo_btn = findViewById(R.id.inKo_btn);
        outKo_btn = findViewById(R.id.outKo_btn);
        inEn_btn = findViewById(R.id.inEn_btn);
        outEn_btn = findViewById(R.id.outEn_btn);
        speachtest_btn = findViewById(R.id.speachtestBtn);

        inputTranslateUp = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.translate_up);
        inputTranslateDown = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.translate_down);
        inputTranslateUp.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                setInLngList.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        outputTranslateUp = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.translate_up);
        outputTranslateDown = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.translate_down);
        outputTranslateUp.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                setOutLngList.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        //tts언어 기본 설정
        tts0 = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != ERROR) {
                    tts0.setLanguage(Locale.KOREAN);
                }
            }
        });
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != ERROR) {
                    tts.setLanguage(Locale.ENGLISH);
                }
            }
        });


        //기본텍스트 언어 선택 메소드
        setInLng_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (inputIsShown == true) {
                    setInLngList.startAnimation(inputTranslateUp);
                } else {
                    setInLngList.startAnimation(inputTranslateDown);
                    setInLngList.setVisibility(View.VISIBLE);
                }
                inputIsShown = !inputIsShown;
            }
        });

        inKo_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");
                tts0.setLanguage(Locale.KOREAN);
                setInLngList.startAnimation(inputTranslateUp);
                setInLng_btn.setText(inKo_btn.getText().toString());
                inputIsShown = false;
            }
        });

        inEn_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-EN");
                tts0.setLanguage(Locale.ENGLISH);
                setInLngList.startAnimation(inputTranslateUp);
                setInLng_btn.setText(inEn_btn.getText().toString());
                inputIsShown = false;
            }
        });

        //번역할 언어 선택 메소드들
        setOutLng_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (outputIsShown == true) {
                    setOutLngList.startAnimation(outputTranslateUp);
                } else {
                    setOutLngList.startAnimation(outputTranslateDown);
                    setOutLngList.setVisibility(View.VISIBLE);
                }
                outputIsShown = !outputIsShown;
            }
        });

        outKo_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tts.setLanguage(Locale.KOREAN);
                setOutLngList.startAnimation(outputTranslateUp);
                setOutLng_btn.setText(outKo_btn.getText().toString());
                outputIsShown = false;
            }
        });

        outEn_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tts.setLanguage(Locale.ENGLISH);
                setOutLngList.startAnimation(outputTranslateUp);
                setOutLng_btn.setText(outEn_btn.getText().toString());
                outputIsShown = false;
            }
        });

        //번역 버튼 메소드
        btnTranslate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendRequest();
            }
        });

        //tts버튼
        btnSpeak0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (inputText.getText().toString() == "") {
                    Toast.makeText(PapagoActivity.this, "텍스트를 입력해주세요", Toast.LENGTH_SHORT).show();
                } else {
                    tts0.speak(inputText.getText().toString(), TextToSpeech.QUEUE_FLUSH, null);
                }
            }
        });

        btnSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (outText.getText().toString() == "") {
                    Toast.makeText(PapagoActivity.this, "텍스트를 입력해주세요", Toast.LENGTH_SHORT).show();
                } else {
                    tts.speak(outText.getText().toString(), TextToSpeech.QUEUE_FLUSH, null);
                }
            }
        });

        //stop버튼
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tts.isSpeaking()) {
                    tts.stop();
                }
                else if (tts0.isSpeaking()) {
                    tts0.stop();
                }
                else {
                    Toast.makeText(PapagoActivity.this, "입력된 값이 없습니다.", Toast.LENGTH_SHORT).show();

                }
            }
        });

        //이미지 텍스트로 이동
        btnImageText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PapagoActivity.this, ocr.class);
                startActivity(intent);
            }
        });

        //stt기능 버튼
        btnVoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OPTION=1;
                VoiceTask voiceTask = new VoiceTask();
                voiceTask.execute();
            }
        });

        speachtest_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OPTION=2;
                VoiceTask voiceTask0 = new VoiceTask();
                voiceTask0.execute();
            }
        });
    }

    public void sendRequest() {
        if (setInLng_btn.getText().toString().equals("한국어")) {
            inputLng = "ko";
        } else if (setInLng_btn.getText().toString().equals("영어")) {
            inputLng = "en";
        }

        if (setOutLng_btn.getText().toString().equals("한국어")) {
            outputLng = "ko";
        } else if (setOutLng_btn.getText().toString().equals("영어")) {
            outputLng = "en";
        }

        Request request = new StringRequest(
                Request.Method.POST,
                ApiHelper.host,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String body = null;
                        try {
                            body = new String(error.networkResponse.data, "UTF-8");
                            Log.d("PaPagoActivity", body);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
        ) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("X-Naver-Client-Id", ApiHelper.clientId);
                params.put("X-Naver-Client-Secret", ApiHelper.clientSecret);

                return params;
            }

            @Override
            public Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("source", inputLng);
                params.put("target", outputLng);
                params.put("text", inputText.getText().toString());

                return params;
            }
        };

        request.setShouldCache(false);
        ApiHelper.requestQueue.add(request);
    }

    public void processResponse(String response) {
        Gson gson = new Gson();
        TranslationMessage translationMessage = gson.fromJson(response, TranslationMessage.class);
        if (translationMessage != null) {
            outText.setText(translationMessage.message.result.translatedText);
        }
    }

    public class VoiceTask extends AsyncTask<String, Integer, String> {
        String str = null;

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {
                getVoice();
            } catch (Exception e) {
                // TODO: handle exception
            }
            return str;
        }

        @Override
        protected void onPostExecute(String result) {
            try {

            } catch (Exception e) {
                Log.d("onActivityResult", "getImageURL exception");
            }
        }
    }

    private void getVoice() {

        Intent intent = new Intent();
        intent.setAction(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);

        String language = "ko-KR";

        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
        startActivityForResult(intent, 2);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {

            ArrayList<String> results = data
                    .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

            String str = results.get(0);
            Toast.makeText(getBaseContext(), str, Toast.LENGTH_SHORT).show();

            if(OPTION==1){
                inputText.setText(str);
            }
            else if(OPTION==2){
                inputText2.setText(str);
            }

        }
    }

}