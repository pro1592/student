package com.example.studyapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.PostViewHolder> {

    private ArrayList<PostList> arrayList;
    private Context context;

    public PostAdapter(ArrayList<PostList> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public PostAdapter.PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_post_retrieved, parent, false);
        PostAdapter.PostViewHolder holder = new PostAdapter.PostViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull PostAdapter.PostViewHolder holder, int position) {
        holder.postTitleText.setText(String.valueOf(arrayList.get(position).getTitle()));
        holder.postContentText.setText(String.valueOf(arrayList.get(position).getContent()));
        holder.postDateText.setText(String.valueOf(arrayList.get(position).getDate()));
    }

    @Override
    public int getItemCount() {
        return (arrayList != null ? arrayList.size() : 0);
    }

    public class PostViewHolder extends RecyclerView.ViewHolder{

        TextView postTitleText;
        TextView postContentText;
        TextView postDateText;

        public PostViewHolder(@NonNull View itemView) {
            super(itemView);

            this.postTitleText = itemView.findViewById(R.id.postTitleTv);
            this.postContentText = itemView.findViewById(R.id.postContentTv);
            this.postDateText = itemView.findViewById(R.id.titleDateTv);
        }
    }

}
