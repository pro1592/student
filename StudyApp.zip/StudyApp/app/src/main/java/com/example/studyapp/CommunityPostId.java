package com.example.studyapp;

import androidx.annotation.NonNull;

import com.google.firebase.firestore.Exclude;

public class CommunityPostId {

    @Exclude
    public String CommunityPostId;

    public <T extends CommunityPostId> T withId(@NonNull final String id){
        this.CommunityPostId = id;
        return (T) this;
    }

}
