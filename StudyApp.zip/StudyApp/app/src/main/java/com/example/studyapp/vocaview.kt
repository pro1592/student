package com.example.studyapp

import android.content.DialogInterface
import android.media.MediaRouter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.example.studyapp.databinding.ActivityVocaviewBinding
import com.google.android.material.snackbar.Snackbar
import java.util.*

class vocaview : AppCompatActivity() {

    private var mBinding: ActivityVocaviewBinding? = null

    private val binding get() = mBinding!!

    private lateinit var recyclerView: RecyclerView
    private lateinit var recyclerAdapter: RecyclerAdapter

    private var vocaList = mutableListOf<String>()
    private var displayList = mutableListOf<String>()

    private lateinit var deletedvoca: String


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mBinding = ActivityVocaviewBinding.inflate(layoutInflater)
        setContentView(binding.root)




        vocaList.add("account for 설명하다, 차지하다")
        vocaList.add("adhere to 지키다, 준수하다")
        vocaList.add("apply for 지원하다, 신청하다")
        vocaList.add("apply to 적용되다")
        vocaList.add("at all times 언제나, 항상")
        vocaList.add("at once 즉시, 당장")
        vocaList.add("at the latest 늦어도")
        vocaList.add("be accustomed ~에 익숙하다")
        vocaList.add("be appreciative ~에 감사하다")
        vocaList.add("be associated with ~와 관련되다")
        vocaList.add("be aware of ~을 알다")
        vocaList.add("be based on ~에 기초하다")
        vocaList.add("be capable of ~할 수 있다")
        vocaList.add("be committed to ~에 헌신하다")
        vocaList.add("be compatible with ~와 호환 가능하다")
        vocaList.add("be consistent with ~와 일관되다")
        vocaList.add("be contingent on/upon ~에 달려 있다")
        vocaList.add("be dedicated to ~와 헌신하다")
        vocaList.add("be dependent on ~에 의존하다")
        vocaList.add("be devoted to ~에 헌신하다")
        vocaList.add("be eligible for ~에 자격이 있다")
        vocaList.add("be engaged in ~에 종사하다")
        vocaList.add("be entitled to ~의 자격이 있다")
        vocaList.add("be equipped with ~을 갖추고 있다")
        vocaList.add("be exempt from ~에서 면제되다")
        vocaList.add("be exposed to ~에 노출되다")
        vocaList.add("be faced with ~에 직면하다")
        vocaList.add("be familiar with ~에 익숙하다")
        vocaList.add("be famous for ~로 유명하다")
        vocaList.add("be filled with ~로 가득 차다")
        vocaList.add("be interested in ~에 관심 있다")
        vocaList.add("be involved in ~에 관련되다")
        vocaList.add("be related to ~와 관계가 있다")
        vocaList.add("be resistant to ~에 잘 견디다")
        vocaList.add("be responsible for ~에 책임이 있다")
        vocaList.add("be satisfied with ~에 만족하다")
        vocaList.add("be similar to ~와 유사하다")
        vocaList.add("be subject to ~될 수 있다")
        vocaList.add("be suitable ~에 적당하다")
        vocaList.add("be used to ~에 익숙하다")
        vocaList.add("by chance 우연히, 뜻밖에")
        vocaList.add("by means of ~에 의해서")
        vocaList.add("comply with 지키다, 준수하다")
        vocaList.add("concentrate on 집중하다, 전념하다")
        vocaList.add("conform to 따르다, 지키다")
        vocaList.add("consist of ~로 구성되다")
        vocaList.add("contribute to ~에 기여하다")
        vocaList.add("cope with 대처하다, 처리하다")
        vocaList.add("deal with 다루다")
        vocaList.add("dispose of 처리하다, 폐기하다")
        vocaList.add("enroll in ~에 등록하다")
        vocaList.add("for example 예를 들어")
        vocaList.add("for free 무료로")
        vocaList.add("go into effect 효력이 발생되다")
        vocaList.add("in a timely manner 빠른 시일내에")
        vocaList.add("in accordance with ~에 따라서")
        vocaList.add("in advance ~사전에, 미리")
        vocaList.add("in celebration of ~을 축하하여")
        vocaList.add("in charge of ~을 담당하는")
        vocaList.add("in compliance with ~을 준수하는")
        vocaList.add("in conjunction with ~와 같이")
        vocaList.add("in contrast 그에 반해서")
        vocaList.add("in cooperation with ~와 협력해서")
        vocaList.add("in general 일반적으로")
        vocaList.add("in honor of ~을 축하하기 위해")
        vocaList.add("in observance of ~을 기념해서")
        vocaList.add("in person 직접")
        vocaList.add("in preparation for ~에 대비해서")
        vocaList.add("in reference to ~에 관해서")
        vocaList.add("in short 요약하면")
        vocaList.add("in terms of ~라는 점에서")
        vocaList.add("in the meantime 그 동안에")
        vocaList.add("inquire about 질문하다, 문의하다")
        vocaList.add("interfere with 방해하다, 간섭하다")
        vocaList.add("look into 조사하다")
        vocaList.add("object to 반대하다")
        vocaList.add("on a regular basis 정기적으로")
        vocaList.add("on behalf of ~을 대표해서")
        vocaList.add("on duty 근무 중인")
        vocaList.add("on purpose 고의로, 일부러")
        vocaList.add("on the other hand 반면에")
        vocaList.add("out of stock 품절된, 재고가 없는")
        vocaList.add("out of town 출장중인")
        vocaList.add("participate in 참가하다")
        vocaList.add("pay attention to ~에 주목하다")
        vocaList.add("pertaining to ~와 관련된, ~에 관해서")
        vocaList.add("put off 미루다, 연기하다")
        vocaList.add("qualify for ~받을 자격이 있다")
        vocaList.add("refrain from 자제하다, 삼가다")
        vocaList.add("register for 등록하다, 신청하다")
        vocaList.add("respond to 응답하다")
        vocaList.add("specialize in 전문으로 하다")
        vocaList.add("subscribe to 정기 구독하다")
        vocaList.add("take advantage of 이용하다")
        vocaList.add("take into account 고려하다")
        vocaList.add("take over 인수하다")
        vocaList.add("under construction 공사중인")
        vocaList.add("upon arrival 도착하자 마자")
        vocaList.add("upon request 요청에 따라")
        vocaList.add("with regard to ~에 관해서")













        displayList.addAll(vocaList)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerAdapter = RecyclerAdapter(displayList)

        recyclerView.adapter = recyclerAdapter

        val itemTouchHelper = ItemTouchHelper(simpleCallback)
        itemTouchHelper.attachToRecyclerView(recyclerView)



        binding.swipeRefreshLayout.setOnRefreshListener {
            displayList.clear()
            displayList.addAll(vocaList)
            recyclerView.adapter!!.notifyDataSetChanged()
            binding.swipeRefreshLayout.isRefreshing = false
        }





    }

    private  var simpleCallback = object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP.or(ItemTouchHelper.DOWN),ItemTouchHelper.LEFT.or(ItemTouchHelper.RIGHT)){
        override fun onMove(
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder,
            target: RecyclerView.ViewHolder
        ): Boolean {
            var startPosition = viewHolder.adapterPosition
            var endPosition = target.adapterPosition

            Collections.swap(displayList, startPosition, endPosition)
            recyclerView.adapter?.notifyItemMoved(startPosition, endPosition)
            return true
        }

        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
            var position = viewHolder.adapterPosition

            when(direction){
                ItemTouchHelper.LEFT -> {
                    deletedvoca = displayList.get(position)
                    displayList.removeAt(position)
                    recyclerAdapter.notifyItemRemoved(position)

                    Snackbar.make(recyclerView, "$deletedvoca is deleted", Snackbar.LENGTH_LONG).setAction("되돌리기", View.OnClickListener {
                        displayList.add(position, deletedvoca)
                        recyclerAdapter.notifyItemInserted(position)
                    }).show()
                }


                ItemTouchHelper.RIGHT -> {
                    var editText = EditText(this@vocaview)
                    editText.setText(displayList[position])

                    val builder = AlertDialog.Builder(this@vocaview)
                    builder.setTitle("새로 만들기")
                    builder.setCancelable(true)
                    builder.setView(editText)

                    builder.setNegativeButton("취소", DialogInterface.OnClickListener { dialog, which ->
                        displayList.clear()
                        displayList.addAll(vocaList)
                        recyclerView.adapter!!.notifyDataSetChanged()
                    })

                    builder.setPositiveButton("갱신", DialogInterface.OnClickListener { dialog, which ->
                        displayList.set(position, editText.getText().toString())
                        recyclerView.adapter!!.notifyItemChanged(position)
                    })

                    builder.show()
                }
            }

        }


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)

        var item: MenuItem = menu!!.findItem(R.id.action_search)

        if (item != null){
            var searchView = item.actionView as SearchView

            searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
                override fun onQueryTextSubmit(query: String?): Boolean {
                    return true
                }

                override fun onQueryTextChange(newText: String?): Boolean {

                    if (newText!!.isNotEmpty()) {
                        displayList.clear()
                        var search = newText.toLowerCase(Locale.getDefault())

                        for(country in vocaList){
                            if(country.toLowerCase(Locale.getDefault()).contains(search)){
                                displayList.add(country)
                            }
                            recyclerView.adapter!!.notifyDataSetChanged()

                        }
                    }else{
                        displayList.clear()
                        displayList.addAll(vocaList)
                        recyclerView.adapter!!.notifyDataSetChanged()

                    }

                    return true
                }

            })
        }

        return super.onCreateOptionsMenu(menu)
    }
}