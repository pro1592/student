package com.example.studyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class newspage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newspage);





        Button option3 =  findViewById(R.id.option3);
        option3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ted.com/talks?language=ko"));
                startActivity(intent);
            }
        });



        Button option4 = findViewById(R.id.option4);
        option4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.koreatimes.co.kr/www2/index.asp"));
                startActivity(intent);
            }
        });

        Button option5 = findViewById(R.id.option5);
        option5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.audioenglish.org/"));
                startActivity(intent);
            }
        });

        Button option6 = findViewById(R.id.option6);
        option6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.englishspeak.com/ko/english-lessons"));
                startActivity(intent);
            }
        });


        Button option7 = findViewById(R.id.option7);
        option7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://dic.impact.pe.kr/"));
                startActivity(intent);
            }
        });















    }
}