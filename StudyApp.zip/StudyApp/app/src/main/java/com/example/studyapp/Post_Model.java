package com.example.studyapp;

import java.sql.Timestamp;

public class Post_Model {

    private String title, content, date, PostId, userId;
    private Object timestamp;

    public Post_Model(String title, String content, String date, String PostId, String userId, Object timestamp) {
        this.title = title;
        this.content = content;
        this.date = date;
        this.PostId = PostId;
        this.userId = userId;
        this.timestamp = timestamp;
    }

    public String getTitle() { return title; }

    public void setTitle(String title) { this.title = title; }

    public String getContent() { return content; }

    public void setContent(String content) { this.content = content; }

    public String getDate() { return date; }

    public void setDate(String date) { this.date = date; }

    public String getPostId() { return PostId; }

    public void setPostId(String id) { this.PostId = id; }

    public String getUserId() { return userId; }

    public void setUserId(String userId) { this.userId = userId; }

    public Object getTimestamp() { return timestamp; }

    public void setTimestamp(Object timestamp) { this.timestamp = timestamp; }
}
