package com.example.studyapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.studyapp.databinding.ActivityRecyclerViewKtBinding

class RecyclerViewKt : AppCompatActivity() {


    private var mBinding: ActivityRecyclerViewKtBinding? = null
    private val binding get() = mBinding!!







    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityRecyclerViewKtBinding.inflate(layoutInflater)
        setContentView(binding.root)
















        val profileList = arrayListOf(
            Profiles(R.drawable.tap, "account for", "1.", "설명하다, 차지하다"),
            Profiles(R.drawable.tap, "adhere to", "2.", "지키다, 준수하다"),
            Profiles(R.drawable.tap, "apply for", "3.", "지원하다, 신청하다"),
            Profiles(R.drawable.tap, "apply to", "4.", "적용되다"),
            Profiles(R.drawable.tap, "at all times", "5.", "언제나, 항상"),
            Profiles(R.drawable.tap, "at once", "6.", "즉시, 당장"),
            Profiles(R.drawable.tap, "at the latest", "7.", "늦어도"),
            Profiles(R.drawable.tap, "be accustomed to", "8.", "~에 익숙하다"),
            Profiles(R.drawable.tap, "be appreciative of", "9.", "~에 감사하다"),
            Profiles(R.drawable.tap, "be associated with", "10.", "~와 관련되다"),
            Profiles(R.drawable.tap, "be aware of", "11.", "~을 알다"),
            Profiles(R.drawable.tap, "be based on", "12.", "~에 기초하다"),
            Profiles(R.drawable.tap, "be capable of", "13.", "~할 수 있다"),
            Profiles(R.drawable.tap, "be committed to", "14.", "~에 헌신하다"),
            Profiles(R.drawable.tap, "be compatible with", "15.", "~와 호환 가능하다"),
            Profiles(R.drawable.tap, "be consistent with", "16.", "~와 일관되다"),
            Profiles(R.drawable.tap, "be contingent on/upon", "17.", "~에 달려 있다"),
            Profiles(R.drawable.tap, "be dedicated to", "18.", "~와 헌신하다"),
            Profiles(R.drawable.tap, "be dependent on", "19.", "~에 의존하다"),
            Profiles(R.drawable.tap, "be devoted to", "20.", "~에 헌신하다"),
            Profiles(R.drawable.tap, "be eligible for", "21.", "~에 자격이 있다"),
            Profiles(R.drawable.tap, "be engaged in", "22.", "~에 종사하다"),
            Profiles(R.drawable.tap, "be entitled to", "23.", "~의 자격이 있다"),
            Profiles(R.drawable.tap, "be equipped with", "24.", "~을 갖추고 있다"),
            Profiles(R.drawable.tap, "be exempt from", "25.", "~에서 면제되다"),
            Profiles(R.drawable.tap, "be exposed to", "26.", "~에 노출되다"),
            Profiles(R.drawable.tap, "be faced with", "27.", "~에 직면하다"),
            Profiles(R.drawable.tap, "be familiar with", "28.", "~에 익숙하다"),
            Profiles(R.drawable.tap, "be famous for", "29.", "~로 유명하다"),
            Profiles(R.drawable.tap, "be filled with", "30.", "~로 가득 차다"),
            Profiles(R.drawable.tap, "be interested in", "31.", "~에 관심 있다"),
            Profiles(R.drawable.tap, "be involved in", "32.", "~에 관련되다"),
            Profiles(R.drawable.tap, "be related to", "33.", "~와 관계가 있다"),
            Profiles(R.drawable.tap, "be resistant to", "34.", "~에 잘 견디다"),
            Profiles(R.drawable.tap, "be responsible for", "35.", "~에 책임이 있다"),
            Profiles(R.drawable.tap, "be satisfied with", "36.", "~에 만족하다"),
            Profiles(R.drawable.tap, "be similar to", "37.", "~와 유사하다"),
            Profiles(R.drawable.tap, "be subject to", "38.", "~될 수 있다"),
            Profiles(R.drawable.tap, "be suitable", "39.", "~에 적당하다"),
            Profiles(R.drawable.tap, "be used to", "40.", "~에 익숙하다"),
            Profiles(R.drawable.tap, "by chance", "41.", "우연히, 뜻밖에"),
            Profiles(R.drawable.tap, "by means of", "42.", "~에 의해서"),
            Profiles(R.drawable.tap, "comply with", "43.", "지키다, 준수하다"),
            Profiles(R.drawable.tap, "concentrate on", "44.", "집중하다, 전념하다"),
            Profiles(R.drawable.tap, "conform to", "45.", "따르다, 지키다"),
            Profiles(R.drawable.tap, "consist of", "46.", "~로 구성되다"),
            Profiles(R.drawable.tap, "contribute to", "47.", "~에 기여하다"),
            Profiles(R.drawable.tap, "cope with", "48.", "대처하다, 처리하다"),
            Profiles(R.drawable.tap, "deal with", "49.", "다루다"),
            Profiles(R.drawable.tap, "dispose of", "50.", "처리하다, 폐기하다"),
            Profiles(R.drawable.tap, "enroll in", "51.", "~에 등록하다"),
            Profiles(R.drawable.tap, "for example", "52.", "예를 들어"),
            Profiles(R.drawable.tap, "for free", "53.", "무료로"),
            Profiles(R.drawable.tap, "go into effect", "54.", "효력이 발생되다"),
            Profiles(R.drawable.tap, "in a timely manner", "55.", "빠른 시일내에"),
            Profiles(R.drawable.tap, "in accordance with", "56.", "~에 따라서"),
            Profiles(R.drawable.tap, "in advance", "57.", "~사전에, 미리"),
            Profiles(R.drawable.tap, "in celebration of", "58.", "~을 축하하여"),
            Profiles(R.drawable.tap, "in charge of", "59.", "~을 담당하는"),
            Profiles(R.drawable.tap, "in compliance with", "60.", "~을 준수하는"),
            Profiles(R.drawable.tap, "in conjunction with", "61.", "~와 같이"),
            Profiles(R.drawable.tap, "in contrast", "62.", "그에 반해서"),
            Profiles(R.drawable.tap, "in cooperation with", "63.", "~와 협력해서"),
            Profiles(R.drawable.tap, "in general", "64.", "일반적으로"),
            Profiles(R.drawable.tap, "in honor of", "65.", "~을 축하하기 위해"),
            Profiles(R.drawable.tap, "in observance of", "66.", "~을 기념해서"),
            Profiles(R.drawable.tap, "in person", "67.", "직접"),
            Profiles(R.drawable.tap, "in preparation for", "68.", "~에 대비해서"),
            Profiles(R.drawable.tap, "in reference to", "69.", "~에 관해서"),
            Profiles(R.drawable.tap, "in short", "70.", "요약하면"),
            Profiles(R.drawable.tap, "in terms of", "71.", "~라는 점에서"),
            Profiles(R.drawable.tap, "in the meantime", "72.", "그 동안에"),
            Profiles(R.drawable.tap, "inquire about", "73.", "질문하다, 문의하다"),
            Profiles(R.drawable.tap, "interfere with", "74.", "방해하다, 간섭하다"),
            Profiles(R.drawable.tap, "look into", "75.", "조사하다"),
            Profiles(R.drawable.tap, "object to", "76.", "반대하다"),
            Profiles(R.drawable.tap, "on a regular basis", "77.", "정기적으로"),
            Profiles(R.drawable.tap, "on behalf of", "78.", "~을 대표해서"),
            Profiles(R.drawable.tap, "on duty", "79.", "근무 중인"),
            Profiles(R.drawable.tap, "on purpose", "80.", "고의로, 일부러"),
            Profiles(R.drawable.tap, "on the other hand", "81.", "반면에"),
            Profiles(R.drawable.tap, "out of stock", "82.", "품절된, 재고가 없는"),
            Profiles(R.drawable.tap, "out of town", "83.", "출장중인"),
            Profiles(R.drawable.tap, "participate in", "84.", "참가하다"),
            Profiles(R.drawable.tap, "pay attention to", "85.", "~에 주목하다"),
            Profiles(R.drawable.tap, "pertaining to", "86.", "~와 관련된, ~에 관해서"),
            Profiles(R.drawable.tap, "put off", "87.", "미루다, 연기하다"),
            Profiles(R.drawable.tap, "qualify for", "88.", "~받을 자격이 있다"),
            Profiles(R.drawable.tap, "refrain from", "89.", "자제하다, 삼가다"),
            Profiles(R.drawable.tap, "register for", "90.", "등록하다, 신청하다"),
            Profiles(R.drawable.tap, "respond to", "91.", "응답하다"),
            Profiles(R.drawable.tap, "specialize in", "92.", "전문으로 하다"),
            Profiles(R.drawable.tap, "subscribe to", "93.", "정기 구독하다"),
            Profiles(R.drawable.tap, "take advantage of", "94.", "이용하다"),
            Profiles(R.drawable.tap, "take into account", "95.", "고려하다"),
            Profiles(R.drawable.tap, "take over", "96.", "인수하다"),
            Profiles(R.drawable.tap, "under construction", "97.", "공사중인"),
            Profiles(R.drawable.tap, "upon arrival", "98.", "도착하자 마자"),
            Profiles(R.drawable.tap, "upon request", "99.", "요청에 따라"),
            Profiles(R.drawable.tap, "with regard to", "100.", "~에 관해서")


        )


        binding.rvProfile.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        binding.rvProfile.setHasFixedSize(true)

        binding.rvProfile.adapter = ProfileAdapter(profileList)




    }


    override fun onDestroy() {

        mBinding = null
        super.onDestroy()
    }
}

class ActivityRecyclerViewKtBinding {

}