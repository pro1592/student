package com.example.studyapp;

public class TranslationMessage {
    public TranslationMessageItem message;
}
