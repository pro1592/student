package com.example.studyapp;

public class TranslationResult {
    public String srcLangType;
    public String traLangType;
    public String translatedText;
    public String engineType;
    public String pivot;
}
