package com.example.studyapp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class CommunityFragment extends Fragment {

    private RecyclerView post_list_view;
    private List<CommunityPost> community_list;
    private List<CommunityUser> user_list;

    private CommunityRecyclerAdapter communityRecyclerAdapter;

    private DocumentSnapshot lastVisible;
    private Boolean isFirstPageFirstLoad = true;

    private FirebaseFirestore firebaseFirestore;
    private FirebaseAuth firebaseAuth;

    public CommunityFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_community, container, false);

        community_list = new ArrayList<>();
        user_list = new ArrayList<>();
        post_list_view = view.findViewById(R.id.community_post_list_recyclerView);

        firebaseAuth = FirebaseAuth.getInstance();

        communityRecyclerAdapter = new CommunityRecyclerAdapter(community_list, user_list);
        post_list_view.setLayoutManager(new LinearLayoutManager(container.getContext()));
        post_list_view.setAdapter(communityRecyclerAdapter);

        if (firebaseAuth.getCurrentUser() != null) {

            firebaseFirestore = FirebaseFirestore.getInstance();

            post_list_view.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                    super.onScrolled(recyclerView, dx, dy);

                    Boolean reachedBottom = !recyclerView.canScrollVertically(-1);

                    if(reachedBottom){

                        //String desc = lastVisible.getString("desc");
                        //Toast.makeText(container.getContext(), "게시글 : " + desc, Toast.LENGTH_SHORT).show();

                        loadMorePost();

                    }

                }
            });

            Query firstQuery = firebaseFirestore.collection("Posts").orderBy("timestamp", Query.Direction.DESCENDING).limit(3);
            firstQuery.addSnapshotListener(new EventListener<QuerySnapshot>() {
                @Override
                public void onEvent(@Nullable QuerySnapshot documentSnapshots, @Nullable FirebaseFirestoreException error) {

                    //if (!documentSnapshots.isEmpty()) {

                    if (isFirstPageFirstLoad) {

                        lastVisible = documentSnapshots.getDocuments().get(documentSnapshots.size() - 1);
                        community_list.clear();
                        user_list.clear();
                    }

                    for (DocumentChange doc : documentSnapshots.getDocumentChanges()) {
                        if (doc.getType() == DocumentChange.Type.ADDED) {

                            String communityPostId = doc.getDocument().getId();
                            CommunityPost communityPost = doc.getDocument().toObject(CommunityPost.class).withId(communityPostId);

                            String communityUserId = doc.getDocument().getString("user_id");
                            firebaseFirestore.collection("Users").document(communityUserId).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {

                                    if (task.isSuccessful()){

                                        CommunityUser user = task.getResult().toObject(CommunityUser.class);

                                        if (!isFirstPageFirstLoad) {

                                            user_list.add(user);
                                            community_list.add(communityPost);

                                        } else {

                                            user_list.add(0, user);
                                            community_list.add(0, communityPost);
                                        }

                                        communityRecyclerAdapter.notifyDataSetChanged();

                                    }

                                }
                            });
                        }
                    }

                    isFirstPageFirstLoad = false;

                    //}
                }
            });
        }

        // Inflate the layout for this fragment
        return view;
    }

    public void loadMorePost(){
        Query nextQuery = firebaseFirestore.collection("Posts")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .startAfter(lastVisible)
                .limit(3);

        nextQuery.addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot documentSnapshots, @Nullable FirebaseFirestoreException error) {

                if(!documentSnapshots.isEmpty()) {

                    lastVisible = documentSnapshots.getDocuments().get(documentSnapshots.size() - 1);
                    for (DocumentChange doc : documentSnapshots.getDocumentChanges()) {

                        if (doc.getType() == DocumentChange.Type.ADDED) {

                            String communityPostId = doc.getDocument().getId();
                            CommunityPost communityPost = doc.getDocument().toObject(CommunityPost.class).withId(communityPostId);
                            String communityUserId = doc.getDocument().getString("user_id");

                            firebaseFirestore.collection("Users").document(communityUserId).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {

                                    if (task.isSuccessful()){

                                        CommunityUser user = task.getResult().toObject(CommunityUser.class);

                                        user_list.add(user);
                                        community_list.add(communityPost);

                                        communityRecyclerAdapter.notifyDataSetChanged();

                                    }

                                }
                            });

                        }
                    }
                }
            }
        });
    }

}