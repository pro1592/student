package com.example.studyapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.Date;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class CommunityRecyclerAdapter extends RecyclerView.Adapter<CommunityRecyclerAdapter.ViewHolder> {

    public List<CommunityPost> community_list;
    public List<CommunityUser> user_list;
    public Context context;

    private FirebaseFirestore firebaseFirestore;
    private FirebaseAuth firebaseAuth;

    public CommunityRecyclerAdapter(List<CommunityPost> community_list, List<CommunityUser> user_list){
        this.community_list = community_list;
        this.user_list = user_list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.post_list_item, parent, false);
        context = parent.getContext();
        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        holder.setIsRecyclable(false);

        String communityPostId = community_list.get(position).CommunityPostId;
        String currentUserId = firebaseAuth.getCurrentUser().getUid();

        String desc_data = community_list.get(position).getDesc();
        holder.setDescText(desc_data);

        String image_url = community_list.get(position).getImage_url();
        String thumbUri = community_list.get(position).getImage_thumb();
        holder.setPostImage(image_url, thumbUri);

        String post_user_id = community_list.get(position).getUser_id();

        if(post_user_id.equals(currentUserId)){

            holder.postDeleteBtn.setEnabled(true);
            holder.postDeleteBtn.setVisibility(View.VISIBLE);

        }

        String userName = user_list.get(position).getName();
        String userImage = user_list.get(position).getImage();

        holder.setUserData(userName, userImage);

        try {
            long milliseconds = community_list.get(position).getTimestamp().getTime();
            String dateString = DateFormat.format("yyyy-MM-dd", new Date(milliseconds)).toString();
            holder.setTime(dateString);
        } catch (Exception e){
            Toast.makeText(context, "Exception : " + e, Toast.LENGTH_SHORT).show();
        }

        firebaseFirestore.collection("Posts/" + communityPostId + "/Comments").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot documentSnapshots, @Nullable FirebaseFirestoreException error) {

                if(!documentSnapshots.isEmpty()){

                    int count = documentSnapshots.size();

                    holder.updateCommentsCount(count);

                }else {

                    holder.updateCommentsCount(0);

                }

            }
        });

        holder.postCommentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent commentIntent = new Intent(context, CommentsActivity.class);
                commentIntent.putExtra("community_post_id", communityPostId);
                context.startActivity(commentIntent);
            }
        });

        holder.postDeleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                firebaseFirestore.collection("Posts").document(communityPostId).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        community_list.remove(position);
                        user_list.remove(position);
                        notifyDataSetChanged();
                    }
                });

            }
        });

    }

    @Override
    public int getItemCount() {
        return community_list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private View mView;

        private TextView descView;
        private ImageView postImageView;
        private TextView postDate;

        private TextView postUserName;
        private CircleImageView postUserImage;

        private ImageView postCommentBtn;
        private Button postDeleteBtn;

        private TextView postCommentCount;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;

            postCommentBtn = mView.findViewById(R.id.post_comment);
            postDeleteBtn = mView.findViewById(R.id.post_delete_btn);
        }

        public void setDescText(String descText){

            descView = mView.findViewById(R.id.post_desc);
            descView.setText(descText);

        }

        public void setPostImage(String downloadUri, String thumbUri) {

            postImageView = mView.findViewById(R.id.post_image);

            RequestOptions requestOptions = new RequestOptions();
            requestOptions.placeholder(R.drawable.addimage);

            Glide.with(context).applyDefaultRequestOptions(requestOptions).load(downloadUri).thumbnail(
                    Glide.with(context).load(thumbUri)
            ).into(postImageView);

        }

        public void setTime(String date){

            postDate = mView.findViewById(R.id.post_date);
            postDate.setText(date);

        }

        public void setUserData(String name, String image){
            postUserImage = mView.findViewById(R.id.post_user_image);
            postUserName = mView.findViewById(R.id.post_user_name);

            postUserName.setText(name);

            RequestOptions placeholderOption = new RequestOptions();
            placeholderOption.placeholder(R.drawable.default_profile3);

            Glide.with(context).applyDefaultRequestOptions(placeholderOption).load(image).into(postUserImage);

        }

        public void updateCommentsCount(int count){
            postCommentCount = mView.findViewById(R.id.post_comment_count);
            postCommentCount.setText("댓글 수 : " + count);
        }

    }

}
