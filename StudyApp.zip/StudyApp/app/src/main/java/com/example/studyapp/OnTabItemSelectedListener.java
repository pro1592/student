package com.example.studyapp;

public interface OnTabItemSelectedListener {
    public void onTabSelected(int position);
}
