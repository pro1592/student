package com.example.studyapp

class Profiles(val gender: Int, val app:String, val num:String, val mean:String)