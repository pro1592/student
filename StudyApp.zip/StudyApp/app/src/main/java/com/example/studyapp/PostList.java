package com.example.studyapp;

public class PostList {

    private String title, content, date, PostId, userId;
    private Object timestamp;

    public PostList() {

    }

    public String getTitle() { return title; }

    public void setTitle(String title) { this.title = title; }

    public String getContent() { return content; }

    public void setContent(String content) { this.content = content; }

    public String getDate() { return date; }

    public void setDate(String date) { this.date = date; }

    public String getPostId() { return PostId; }

    public void setPostId(String id) { this.PostId = id; }

    public String getUserId() { return userId; }

    public void setUserId(String userId) { this.userId = userId; }

    public Object getTimestamp() { return timestamp; }

    public void setTimestamp(Object timestamp) { this.timestamp = timestamp; }

}
