package com.example.studyapp;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Frag_community extends Fragment {

    private View view;
    private RecyclerView rv_postRecyclerview;
    private FloatingActionButton btn_postAdd;

    //firebase auth object
    private FirebaseAuth firebaseAuth;

    //firebase data object
    private DatabaseReference mDatabaseReference; // 데이터베이스의 주소를 저장합니다.
    private FirebaseDatabase mFirebaseDatabase; // 데이터베이스에 접근할 수 있는 진입점 클래스입니다.
    private FirebaseUser user;

    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<PostList> arrayList;

    private SimpleDateFormat mFormat = new SimpleDateFormat("yyyy-MM-dd");

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.frag_community, container, false);

        // initializing database
        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();

        mFirebaseDatabase = FirebaseDatabase.getInstance();

        rv_postRecyclerview = view.findViewById(R.id.rv_postview);
        btn_postAdd = view.findViewById(R.id.btn_postAdd);

        layoutManager = new LinearLayoutManager(getActivity());
        rv_postRecyclerview.setLayoutManager(layoutManager);
        arrayList = new ArrayList<>();

        updatePost();

        //추가 버튼 누르면 실행되는 리스너
        btn_postAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addPost();
            }
        });

        return  view;
    }

    private void updatePost(){
        mDatabaseReference = mFirebaseDatabase.getReference().child("post");
        mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //파이어베이스 내의 데이터 받아오는 메서드
                arrayList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {   //반복문으로 데이터 list 추출
                    PostList postList = dataSnapshot.getValue(PostList.class);
                    arrayList.add(0, postList);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        adapter = new PostAdapter(arrayList, getActivity());
        rv_postRecyclerview.setAdapter(adapter);
    }

    private void addPost(){
        AlertDialog.Builder myDialog = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = LayoutInflater.from(getActivity());

        View myView = inflater.inflate(R.layout.post_input_file, null);
        myDialog.setView(myView);

        final AlertDialog dialog = myDialog.create();
        dialog.setCancelable(false);

        final EditText edtPostContent = myView.findViewById(R.id.edtPostContent);
        final EditText edtTitle = myView.findViewById(R.id.edtTitle);
        Button save = myView.findViewById(R.id.btnSavePost);
        Button cancel = myView.findViewById(R.id.btnCancelPost);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Date date = new Date();

                mDatabaseReference = mFirebaseDatabase.getReference().child("post");
                String mTitle = edtTitle.getText().toString().trim();
                String mContent = edtPostContent.getText().toString().trim();
                String mDate = mFormat.format(date);
                String PostId = mDatabaseReference.push().getKey();
                String UserId = user.getUid();
                Object timestamp = ServerValue.TIMESTAMP;

                if(TextUtils.isEmpty(mContent)){
                    edtPostContent.setError("게시물을 작성해주세요");
                    return;
                }else {
                    Post_Model post_model = new Post_Model(mTitle, mContent, mDate, PostId, UserId, timestamp);
                    mDatabaseReference.child(PostId).setValue(post_model).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                //일정이 저장되면 토스메세지로 "일정 저장 됨"
                                Toast.makeText(getActivity(),"게시물 등록 완료",Toast.LENGTH_SHORT).show();
                            }else {
                                String error = task.getException().toString();
                                Toast.makeText(getActivity(),"등록 실패 : " + error,Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }

                dialog.dismiss();
                updatePost();
            }
        });

        dialog.show();
    }
}
