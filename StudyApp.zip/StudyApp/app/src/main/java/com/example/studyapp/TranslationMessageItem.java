package com.example.studyapp;

public class TranslationMessageItem {
    public TranslationResult result;
}
